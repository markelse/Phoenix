<h2>Admin Dashboard</h2>
    
<p>Hi, <?php get_username(); ?></p>
    
<p>This is the default admin dashboard page. It can be edited by editing the file named dashboard within your @_admin template folder.</p>

<p>You can use this space to keep notes or create quick links to commonly accessed pages.</p>