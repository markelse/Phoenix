<h2>Members Dashboard</h2>
    
<p>Hello <?php get_username(); ?>!</p>
    
<p>This is the default members dashboard, you can use this as a placeholder for important new, links or events.</p>
