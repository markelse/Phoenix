<div id="footer">
    <p>&copy; <?php echo date("Y"); echo " {$site_name}"; ?> &Colon; Powered by Phoenix CMS.</p>
</div>
</div>

</body>
</html>