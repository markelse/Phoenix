<?php
include "inc/templates/{$site_theme}/header.php";

include "inc/templates/{$site_theme}/l-sidebar.php";


echo "
<div id='content'>
    <h2>{$page_title}</h2>
        {$page_body}
                    
    <p>Posted in {$page_category}.</p>
</div>";
    
include "inc/templates/{$site_theme}/r-sidebar.php";

include "inc/templates/{$site_theme}/footer.php";