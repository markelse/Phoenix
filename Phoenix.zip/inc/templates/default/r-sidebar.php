<div id="rightcolumn">
<?php
    // Query the database to find out what user level the member is.
    require 'inc/db.inc.php';
                        menu_items("Home");
?>
    </div>