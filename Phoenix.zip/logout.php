<?php
require 'inc/functions.inc.php';
require 'inc/db.inc.php';

logout();